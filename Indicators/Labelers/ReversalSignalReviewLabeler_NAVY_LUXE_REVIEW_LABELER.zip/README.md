# ReversalSignalReviewLabeler

NinjaTrader 8 CSV signal viewer + visual review labeler.

## Purpose
- Load a signal CSV.
- Plot LONG/SHORT entry markers at EntryTime/EntryPrice.
- Optionally draw stop and target lines.
- Ctrl+Click a marker to review MFE/MAE and label it.
- Export labels to `reversal_signal_review_labels.csv`.
- Uses the navy-glass / luxe-gold dashboard style.

## Primary review taxonomy
Use a clean analyzable primary grade:

- A+ Amazing
- A Great
- B Good / Usable
- B- Small but Manageable
- C Questionable
- D Unacceptable
- F Horrid
- U Unsure

Use the Reason / Caution field for the why:
- Clean V / strong rejection
- Good location / key level
- Strong ES/TICK confirmation
- Small move but manageable risk
- Late entry
- Chop / middle of range
- Trend-day fade
- Bad stop / too wide
- No real V
- Weak ES/TICK confirmation
- Too extended
- Long into top / short into bottom
- Good setup but too risky
- Other

## Review rule
Grade the structure visible at the time of entry, not simply whether the trade made money.
A losing trade can still be A/A+ if the setup was structurally clean.
A winning trade can still be D/F if it was ugly luck.

## Supported CSV columns
The parser is tolerant, but preferred columns are:

SignalID, SignalTime, EntryTime, ModelName, ModelAlias, InternalModelID, Side,
EntryPrice, StopPrice, Target1Price, Target2Price, ExitTime, ExitPrice, NetPoints,
Outcome, ReviewPriority, VisualGrade, ReviewNotes, RejectReason, Location

It also tolerates older absorption-style columns such as timestamp_ET, type_abbr,
absorption_value_z, flip_strength_z, mfe_60, mae_60, etc.

## Interaction
- Ctrl+Click marker: open review/label popup.
- Shift+drag dashboard header: snap dashboard to chart corner.
- ShowOutcomePnl defaults false to reduce outcome bias during review.
