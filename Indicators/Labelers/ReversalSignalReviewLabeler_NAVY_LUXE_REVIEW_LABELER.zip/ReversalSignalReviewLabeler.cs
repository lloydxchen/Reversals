// =====================================================================================
//  ReversalSignalReviewLabeler  —  NinjaTrader 8 signal visualizer + fast research labeler
//
//  Purpose:
//    - Load a CSV of model/research signals.
//    - Paint clean chart markers.
//    - Ctrl+Click a marker to review MFE/MAE/context and quickly label it.
//    - Write labels to CSV for analysis.
//    - Uses a navy-glass / luxe-gold dashboard style matching the Reversal Hunter HUD.
//    - Generic schema support: SignalID, SignalTime, EntryTime, ModelName, Side,
//      EntryPrice, StopPrice, Target1Price, Target2Price, ExitTime, ExitPrice,
//      NetPoints, Outcome, ReviewPriority, VisualGrade, ReviewNotes, RejectReason.
//    - Also remains tolerant of older absorption-style CSV column names.
//
//  Install:
//    Documents\NinjaTrader 8\bin\Custom\Indicators\ReversalSignalReviewLabeler.cs
//
//  Notes:
//    - This is intentionally a new indicator name to avoid conflicts with older visualizers.
//    - It does not trade. It is a research/review tool.
// =====================================================================================

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

// Global-scope enums keep NinjaTrader generated partials happy.
public enum RsrReviewFileMode
{
	FolderNewestCsv,
	FolderExactFile,
	FullPath
}

public enum RsrReviewSignalModelFilter
{
	All,
	CustomList,
	AGG,
	XVOL,
	VRNG,
	EFRT,
	STAK,
	DIAG,
	WALL,
	WICK,
	SWPR,
	CDLT,
	CVDD,
	ICEB
}

public enum RsrReviewSideFilter
{
	Both,
	LongOnly,
	ShortOnly
}

public enum RsrReviewOutcomeFilter
{
	All,
	CleanOnly,
	BigMove100Only,
	CleanOrBigMove,
	TinyNoiseOnly,
	HighMaeOnly,
	ProblemOnly,
	NonCleanOnly,
	SwingLegOnly,
	FreshExtremeOnly,
	FractalPivotOnly
}

public enum RsrReviewAnchorMode
{
	CsvSignalHighLow,
	CsvEntryPrice,
	ChartBarHighLow
}

public enum RsrReviewClickMod
{
	Ctrl,
	Alt,
	Shift,
	None
}

public enum RsrReviewDashboardAnchor
{
	TopLeft,
	TopRight,
	BottomLeft,
	BottomRight
}

namespace NinjaTrader.NinjaScript.Indicators.ReversalResearch
{
	public class ReversalSignalReviewLabeler : Indicator
	{
		#region Inputs - files
		[NinjaScriptProperty]
		[Display(Name = "FileMode", Description = "FolderNewestCsv = auto-load newest .csv in InputFolder. FolderExactFile = InputFolder + SignalFileName. FullPath = SignalCsvPath.", Order = 1, GroupName = "01. Files")]
		public RsrReviewFileMode FileMode { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "InputFolder", Description = "Folder to scan for signal CSVs. Blank = Documents\\NinjaTrader 8\\ReversalResearch\\signals_in.", Order = 2, GroupName = "01. Files")]
		public string InputFolder { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "SignalFileName", Description = "Used only when FileMode = FolderExactFile. Example: reversal_signals_review.csv", Order = 3, GroupName = "01. Files")]
		public string SignalFileName { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "SignalCsvPath", Description = "Used only when FileMode = FullPath.", Order = 4, GroupName = "01. Files")]
		public string SignalCsvPath { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "OutputFolder", Description = "Where review labels are exported. Blank = Documents\\NinjaTrader 8\\ReversalResearch\\labels_out.", Order = 5, GroupName = "01. Files")]
		public string OutputFolder { get; set; }

		[NinjaScriptProperty]
		[Range(0, 60)]
		[Display(Name = "AutoReloadSeconds", Description = "Checks for a replaced/new CSV every N seconds. 0 disables auto-reload.", Order = 6, GroupName = "01. Files")]
		public int AutoReloadSeconds { get; set; }

		[NinjaScriptProperty]
		[Range(-24, 24)]
		[Display(Name = "TimestampShiftHours", Description = "Shift CSV timestamps to match the chart. Example: if CSV is ET but chart displays CT, use -1.", Order = 7, GroupName = "01. Files")]
		public int TimestampShiftHours { get; set; }
		#endregion

		#region Inputs - filters
		[NinjaScriptProperty]
		[Display(Name = "ModelFilter", Description = "Toggle which signal family is painted. Use CustomList for multiple specific model aliases/names.", Order = 1, GroupName = "02. Filters")]
		public RsrReviewSignalModelFilter ModelFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "CustomModelList", Description = "Comma-separated model aliases/names for ModelFilter = CustomList. Example: AGG,XVOL,VRNG", Order = 2, GroupName = "02. Filters")]
		public string CustomModelList { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "SideFilter", Description = "Show longs, shorts, or both.", Order = 3, GroupName = "02. Filters")]
		public RsrReviewSideFilter SideFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "OutcomeFilter", Description = "Optional research slicing using the CSV quality/outcome flags.", Order = 4, GroupName = "02. Filters")]
		public RsrReviewOutcomeFilter OutcomeFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowOnlyUnreviewed", Description = "If true, hide signals that already have a saved review label.", Order = 5, GroupName = "02. Filters")]
		public bool ShowOnlyUnreviewed { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "GradeFilter", Description = "Optional comma-separated review grades to show. Example: A+,A,B or F,Horrid. Blank = all.", Order = 6, GroupName = "02. Filters")]
		public string GradeFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseMinAbsorptionZ", Description = "If true, hide rows with absorption_value_z below MinAbsorptionZ.", Order = 5, GroupName = "02. Filters")]
		public bool UseMinAbsorptionZ { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "MinAbsorptionZ", Description = "Minimum absorption z-score when UseMinAbsorptionZ = true.", Order = 6, GroupName = "02. Filters")]
		public double MinAbsorptionZ { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseMinMfe60", Description = "If true, hide rows with mfe_60 below MinMfe60.", Order = 7, GroupName = "02. Filters")]
		public bool UseMinMfe60 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "MinMfe60", Description = "Minimum mfe_60 in points when UseMinMfe60 = true.", Order = 8, GroupName = "02. Filters")]
		public double MinMfe60 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseMaxMae60", Description = "If true, hide rows with mae_60 above MaxMae60.", Order = 9, GroupName = "02. Filters")]
		public bool UseMaxMae60 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "MaxMae60", Description = "Maximum mae_60 in points when UseMaxMae60 = true.", Order = 10, GroupName = "02. Filters")]
		public double MaxMae60 { get; set; }
		#endregion

		#region Inputs - chart display
		[NinjaScriptProperty]
		[Display(Name = "AnchorMode", Description = "Where to place marker vertically: CSV signal high/low, CSV entry price, or actual chart bar high/low.", Order = 1, GroupName = "03. Chart Display")]
		public RsrReviewAnchorMode AnchorMode { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowTextLabels", Description = "If false, only marker triangles are drawn. Cleaner for dense research charts.", Order = 2, GroupName = "03. Chart Display")]
		public bool ShowTextLabels { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowLeaderLine", Description = "Draw a thin connector from marker to label.", Order = 3, GroupName = "03. Chart Display")]
		public bool ShowLeaderLine { get; set; }

		[NinjaScriptProperty]
		[Range(6, 36)]
		[Display(Name = "MarkerSize", Description = "Triangle marker size in pixels.", Order = 4, GroupName = "03. Chart Display")]
		public int MarkerSize { get; set; }

		[NinjaScriptProperty]
		[Range(8, 22)]
		[Display(Name = "LabelFontSize", Description = "Text label size.", Order = 5, GroupName = "03. Chart Display")]
		public int LabelFontSize { get; set; }

		[NinjaScriptProperty]
		[Range(0, 80)]
		[Display(Name = "SignalOffsetTicks", Description = "Vertical offset from high/low/entry when drawing markers.", Order = 6, GroupName = "03. Chart Display")]
		public int SignalOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, 80)]
		[Display(Name = "LabelOffsetPixels", Description = "Pixel gap between marker and text label.", Order = 7, GroupName = "03. Chart Display")]
		public int LabelOffsetPixels { get; set; }

		[NinjaScriptProperty]
		[Range(0, 3000)]
		[Display(Name = "MaxVisibleSignals", Description = "Safety limit for visible markers. 0 = no limit. If cluttered, zoom in or filter by type.", Order = 8, GroupName = "03. Chart Display")]
		public int MaxVisibleSignals { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowStopLines", Description = "Draw each signal's stop line from entry forward.", Order = 9, GroupName = "03. Chart Display")]
		public bool ShowStopLines { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowTargetLines", Description = "Draw target lines from CSV targets and/or fixed point target list.", Order = 10, GroupName = "03. Chart Display")]
		public bool ShowTargetLines { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowOutcomePnl", Description = "Show outcome / PnL on chart labels and dashboard. Keep false during blind structural review.", Order = 11, GroupName = "03. Chart Display")]
		public bool ShowOutcomePnl { get; set; }

		[NinjaScriptProperty]
		[Range(1, 300)]
		[Display(Name = "LineForwardBars", Description = "Approximate number of bars to draw stop/target lines forward.", Order = 12, GroupName = "03. Chart Display")]
		public int LineForwardBars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "FixedTargetPoints", Description = "Comma-separated fixed point targets to draw from entry. Example: 25,50,75,100. Blank disables fixed targets.", Order = 13, GroupName = "03. Chart Display")]
		public string FixedTargetPoints { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "HideNativeChartLabel", Description = "Hide NinjaTrader's normal top-left indicator label for this script.", Order = 9, GroupName = "03. Chart Display")]
		public bool HideNativeChartLabel { get; set; }
		#endregion

		#region Inputs - dashboard
		[NinjaScriptProperty]
		[Display(Name = "ShowDashboard", Description = "Show the navy-glass review dashboard.", Order = 1, GroupName = "04. Dashboard")]
		public bool ShowDashboard { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DashboardAnchor", Description = "Dashboard corner. Hold Shift and drag the header to snap to another corner.", Order = 2, GroupName = "04. Dashboard")]
		public RsrReviewDashboardAnchor DashboardAnchor { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "EnableShiftDragDashboard", Description = "Hold Shift and drag the dashboard header to snap it to a corner.", Order = 3, GroupName = "04. Dashboard")]
		public bool EnableShiftDragDashboard { get; set; }

		[NinjaScriptProperty]
		[Range(300, 520)]
		[Display(Name = "DashboardWidth", Description = "Dashboard width.", Order = 4, GroupName = "04. Dashboard")]
		public int DashboardWidth { get; set; }

		[NinjaScriptProperty]
		[Range(145, 260)]
		[Display(Name = "DashboardHeight", Description = "Dashboard height.", Order = 5, GroupName = "04. Dashboard")]
		public int DashboardHeight { get; set; }

		[NinjaScriptProperty]
		[Range(0, 200)]
		[Display(Name = "DashboardMarginX", Description = "Horizontal margin from chart edge.", Order = 6, GroupName = "04. Dashboard")]
		public int DashboardMarginX { get; set; }

		[NinjaScriptProperty]
		[Range(0, 200)]
		[Display(Name = "DashboardMarginY", Description = "Vertical margin from chart edge.", Order = 7, GroupName = "04. Dashboard")]
		public int DashboardMarginY { get; set; }
		#endregion

		#region Inputs - tagging
		[NinjaScriptProperty]
		[Display(Name = "EnableTagging", Description = "Ctrl/Alt/Shift+Click a marker to label it and export the tag.", Order = 1, GroupName = "05. Tagging")]
		public bool EnableTagging { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "TagClickModifier", Description = "Modifier key for opening the tag popup.", Order = 2, GroupName = "05. Tagging")]
		public RsrReviewClickMod TagClickModifier { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "GradeList", Description = "Comma-separated grade dropdown options.", Order = 3, GroupName = "05. Tagging")]
		public string GradeList { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ReasonList", Description = "Comma-separated reason dropdown options.", Order = 4, GroupName = "05. Tagging")]
		public string ReasonList { get; set; }
		#endregion

		public override string DisplayName
		{
			get { return HideNativeChartLabel ? string.Empty : Name; }
		}

		#region Internal state/classes
		private readonly object gate = new object();

		private class SignalRow
		{
			public int RowNum;
			public string SignalId = "";
			public string Type = "";
			public string TypeAbbr = "";
			public string ModelName = "";
			public string ModelAlias = "";
			public string InternalModelId = "";
			public string Side = "";
			public DateTime TsRaw;       // Primary plotted time. For generic CSVs this is EntryTime when available, otherwise SignalTime.
			public DateTime TsChart;
			public DateTime SignalTimeRaw;
			public DateTime EntryTimeRaw;
			public DateTime ExitTimeRaw;
			public string TsKey = "";
			public string SignalTimeKey = "";
			public string EntryTimeKey = "";
			public string ExitTimeKey = "";
			public string DateEt = "";
			public string TimeEt = "";
			public string AbsorptionBar = "";
			public int BarNumInDay;

			public double EntryPrice = double.NaN;
			public double StopPrice = double.NaN;
			public double Target1Price = double.NaN;
			public double Target2Price = double.NaN;
			public double ExitPrice = double.NaN;
			public double NetPoints = double.NaN;
			public string Outcome = "";
			public string ReviewPriority = "";
			public string LocationContext = "";
			public string CsvVisualGrade = "";
			public string CsvReviewNotes = "";
			public string CsvRejectReason = "";
			public double SigOpen = double.NaN;
			public double SigHigh = double.NaN;
			public double SigLow = double.NaN;
			public double SigClose = double.NaN;
			public double AbsorpHigh = double.NaN;
			public double AbsorpLow = double.NaN;
			public double AbsorpClose = double.NaN;

			public double AbsorptionValue = double.NaN;
			public double AbsorptionZ = double.NaN;
			public double AbsorptionT = double.NaN;
			public double AbsorptionT2 = double.NaN;
			public double DeltaSignal = double.NaN;
			public double DeltaAbsorp = double.NaN;
			public double DeltaZSignal = double.NaN;
			public double DeltaZAbsorp = double.NaN;
			public double FlipStrengthZ = double.NaN;
			public double CumDelta5 = double.NaN;
			public double CvdSession = double.NaN;
			public double VolExtremeShare = double.NaN;
			public double AggrVolExtremeShare = double.NaN;
			public double BarVolume = double.NaN;
			public double StackedImbRun = double.NaN;
			public double DiagImb = double.NaN;
			public bool AtFractalPivot;
			public bool AtSwingLeg;
			public bool Fresh20Extreme;
			public double SwingLegAtr = double.NaN;
			public double DistFromVwapAtr = double.NaN;
			public double Atr14 = double.NaN;
			public double Vix = double.NaN;
			public double SigBarRange = double.NaN;
			public double Mfe30 = double.NaN;
			public double Mae30 = double.NaN;
			public double Mfe60 = double.NaN;
			public double Mae60 = double.NaN;
			public double Mfe120 = double.NaN;
			public double Mae120 = double.NaN;
			public double BarsToMfe60 = double.NaN;
			public double MoveToEod = double.NaN;
			public double MfeMaeRatio60 = double.NaN;
			public bool IsBigMove100;
			public bool IsCleanTrade;
			public bool IsTinyNoise;
			public bool IsHighMae;
		}

		private class TagRow
		{
			public string SignalId = "";
			public string Grade = "";
			public string Reason = "";
			public string Note = "";
			public string UpdatedLocal = "";
		}

		private class Hit
		{
			public float Cx;
			public float Cy;
			public float R;
			public string SignalId;
		}

		private List<SignalRow> signals = new List<SignalRow>();
		private Dictionary<string, SignalRow> signalById = new Dictionary<string, SignalRow>();
		private Dictionary<string, TagRow> tags = new Dictionary<string, TagRow>();
		private List<Hit> hits = new List<Hit>();

		private string effectiveInputFolder = "";
		private string effectiveOutputFolder = "";
		private string resolvedCsvPath = "";
		private string tagPath = "";
		private string loadStatus = "Not loaded";
		private DateTime lastCsvWriteUtc = DateTime.MinValue;
		private DateTime lastTagWriteUtc = DateTime.MinValue;
		private DateTime lastAutoCheck = DateTime.MinValue;
		private int lastVisibleCount = 0;
		private int lastFilteredCount = 0;

		private bool mouseHooked = false;
		private ChartScale cachedScale;
		private Window tagWindow;
		private string[] reasonArr = new string[0];
		private string[] gradeArr = new string[0];
		private string[] gradeFilterArr = new string[0];
		private double[] fixedTargetPointsArr = new double[0];
		private string selectedSignalId = "";

		private SharpDX.DirectWrite.Factory dwFactory;

		private SharpDX.RectangleF lastDashboardRect = new SharpDX.RectangleF();
		private SharpDX.RectangleF lastDashboardHeaderRect = new SharpDX.RectangleF();
		private bool dashboardDragging = false;
		private float dragX = 0f;
		private float dragY = 0f;
		private float dragOffsetX = 0f;
		private float dragOffsetY = 0f;
		#endregion

		#region State/lifecycle
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = "Beautiful CSV signal visualizer and fast reversal research labeler with MFE/MAE review.";
				Name = "ReversalSignalReviewLabeler";
				IsOverlay = true;
				DrawOnPricePanel = true;
				DisplayInDataBox = false;
				PaintPriceMarkers = false;
				IsSuspendedWhileInactive = false;
				Calculate = Calculate.OnPriceChange;

				FileMode = RsrReviewFileMode.FolderNewestCsv;
				InputFolder = "";
				SignalFileName = "reversal_signals_review.csv";
				SignalCsvPath = "";
				OutputFolder = "";
				AutoReloadSeconds = 3;
				TimestampShiftHours = 0;

				ModelFilter = RsrReviewSignalModelFilter.All;
				CustomModelList = "Clean Reclaim Flip,Breadth Hook,Short Exhaustion";
				SideFilter = RsrReviewSideFilter.Both;
				OutcomeFilter = RsrReviewOutcomeFilter.All;
				ShowOnlyUnreviewed = false;
				GradeFilter = "";
				UseMinAbsorptionZ = false;
				MinAbsorptionZ = 1.50;
				UseMinMfe60 = false;
				MinMfe60 = 50.0;
				UseMaxMae60 = false;
				MaxMae60 = 40.0;

				AnchorMode = RsrReviewAnchorMode.CsvSignalHighLow;
				ShowTextLabels = false;
				ShowLeaderLine = true;
				MarkerSize = 15;
				LabelFontSize = 11;
				SignalOffsetTicks = 6;
				LabelOffsetPixels = 10;
				MaxVisibleSignals = 450;
				ShowStopLines = true;
				ShowTargetLines = true;
				ShowOutcomePnl = false;
				LineForwardBars = 42;
				FixedTargetPoints = "25,50,75,100";
				HideNativeChartLabel = true;

				ShowDashboard = true;
				DashboardAnchor = RsrReviewDashboardAnchor.TopRight;
				EnableShiftDragDashboard = true;
				DashboardWidth = 430;
				DashboardHeight = 222;
				DashboardMarginX = 22;
				DashboardMarginY = 26;

				EnableTagging = true;
				TagClickModifier = RsrReviewClickMod.Ctrl;
				GradeList = "A+ Amazing,A Great,B Good / Usable,B- Small but Manageable,C Questionable,D Unacceptable,F Horrid,U Unsure";
				ReasonList = "Clean V / strong rejection,Good location / key level,Strong ES/TICK confirmation,Small move but manageable risk,Late entry,Chop / middle of range,Trend-day fade,Bad stop / too wide,No real V,Weak ES/TICK confirmation,Too extended,Long into top / short into bottom,Good setup but too risky,Other";
			}
			else if (State == State.DataLoaded)
			{
				try { dwFactory = new SharpDX.DirectWrite.Factory(); } catch { }
				ParseLists();
				ResolvePaths();
				LoadTags();
				LoadSignals();
			}
			else if (State == State.Terminated)
			{
				try
				{
					if (mouseHooked && ChartPanel != null)
					{
						ChartPanel.MouseLeftButtonDown -= OnChartMouseDown;
						ChartPanel.MouseMove -= OnChartMouseMove;
						ChartPanel.MouseLeftButtonUp -= OnChartMouseUp;
					}
				}
				catch { }
				mouseHooked = false;
				try { if (dwFactory != null) { dwFactory.Dispose(); dwFactory = null; } } catch { }
				CloseTagWindow();
			}
		}

		protected override void OnBarUpdate()
		{
			// File-driven indicator. Nothing required per bar.
		}
		#endregion

		#region Paths/loading
		private string DefaultRoot()
		{
			return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "ReversalResearch");
		}

		private string CleanPath(string p)
		{
			if (p == null) return "";
			p = p.Trim().Trim('"');
			try { p = Environment.ExpandEnvironmentVariables(p); } catch { }
			return p;
		}

		private void ResolvePaths()
		{
			string root = DefaultRoot();

			effectiveInputFolder = CleanPath(InputFolder);
			if (string.IsNullOrWhiteSpace(effectiveInputFolder))
				effectiveInputFolder = Path.Combine(root, "signals_in");

			effectiveOutputFolder = CleanPath(OutputFolder);
			if (string.IsNullOrWhiteSpace(effectiveOutputFolder))
				effectiveOutputFolder = Path.Combine(root, "labels_out");

			try { Directory.CreateDirectory(effectiveInputFolder); } catch { }
			try { Directory.CreateDirectory(effectiveOutputFolder); } catch { }

			tagPath = Path.Combine(effectiveOutputFolder, "reversal_signal_review_labels.csv");

			resolvedCsvPath = "";
			try
			{
				if (FileMode == RsrReviewFileMode.FullPath)
				{
					resolvedCsvPath = CleanPath(SignalCsvPath);
				}
				else if (FileMode == RsrReviewFileMode.FolderExactFile)
				{
					string fn = string.IsNullOrWhiteSpace(SignalFileName) ? "absorption_signals_all.csv" : SignalFileName.Trim();
					resolvedCsvPath = Path.Combine(effectiveInputFolder, fn);
				}
				else
				{
					string[] files = Directory.Exists(effectiveInputFolder) ? Directory.GetFiles(effectiveInputFolder, "*.csv") : new string[0];
					Array.Sort(files, delegate(string a, string b)
					{
						DateTime aw = File.GetLastWriteTimeUtc(a);
						DateTime bw = File.GetLastWriteTimeUtc(b);
						return bw.CompareTo(aw);
					});
					if (files.Length > 0)
						resolvedCsvPath = files[0];
				}
			}
			catch { resolvedCsvPath = ""; }
		}

		private void ParseLists()
		{
			gradeArr = SplitList(GradeList);
			reasonArr = SplitList(ReasonList);
			gradeFilterArr = SplitList(GradeFilter);
			fixedTargetPointsArr = SplitDoubles(FixedTargetPoints);
		}

		private string[] SplitList(string csv)
		{
			List<string> list = new List<string>();
			if (!string.IsNullOrEmpty(csv))
			{
				string[] parts = csv.Split(',');
				for (int i = 0; i < parts.Length; i++)
				{
					string s = parts[i].Trim();
					if (s.Length > 0) list.Add(s);
				}
			}
			return list.ToArray();
		}

		private double[] SplitDoubles(string csv)
		{
			List<double> list = new List<double>();
			if (!string.IsNullOrEmpty(csv))
			{
				string[] parts = csv.Split(',');
				for (int i = 0; i < parts.Length; i++)
				{
					double v;
					if (double.TryParse((parts[i] ?? "").Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out v))
						list.Add(v);
				}
			}
			return list.ToArray();
		}

		private void CheckAutoReload()
		{
			if (AutoReloadSeconds <= 0) return;
			DateTime now = DateTime.Now;
			if ((now - lastAutoCheck).TotalSeconds < AutoReloadSeconds) return;
			lastAutoCheck = now;

			string oldPath = resolvedCsvPath;
			ResolvePaths();

			DateTime csvWrite = DateTime.MinValue;
			try { if (!string.IsNullOrWhiteSpace(resolvedCsvPath) && File.Exists(resolvedCsvPath)) csvWrite = File.GetLastWriteTimeUtc(resolvedCsvPath); } catch { }

			DateTime tagWrite = DateTime.MinValue;
			try { if (!string.IsNullOrWhiteSpace(tagPath) && File.Exists(tagPath)) tagWrite = File.GetLastWriteTimeUtc(tagPath); } catch { }

			if (!string.Equals(oldPath, resolvedCsvPath, StringComparison.OrdinalIgnoreCase) || csvWrite != lastCsvWriteUtc)
				LoadSignals();
			if (tagWrite != lastTagWriteUtc)
				LoadTags();
		}

		private void LoadSignals()
		{
			List<SignalRow> loaded = new List<SignalRow>();
			Dictionary<string, SignalRow> byId = new Dictionary<string, SignalRow>();

			try
			{
				if (string.IsNullOrWhiteSpace(resolvedCsvPath) || !File.Exists(resolvedCsvPath))
				{
					lock (gate)
					{
						signals = loaded;
						signalById = byId;
						loadStatus = "No CSV found";
						lastCsvWriteUtc = DateTime.MinValue;
						selectedSignalId = "";
					}
					return;
				}

				string[] lines = File.ReadAllLines(resolvedCsvPath);
				if (lines.Length <= 1)
				{
					lock (gate)
					{
						signals = loaded;
						signalById = byId;
						loadStatus = "CSV has no rows: " + Path.GetFileName(resolvedCsvPath);
						lastCsvWriteUtc = File.GetLastWriteTimeUtc(resolvedCsvPath);
						selectedSignalId = "";
					}
					return;
				}

				char delim = lines[0].IndexOf('\t') >= 0 ? '\t' : ',';
				List<string> hdr = SplitCsv(lines[0], delim);
				Dictionary<string, int> ix = HeaderMap(hdr);

				int iSignalTime = HeaderIdx(ix, "signaltime", "signal_time", "signal_time_et", "timestamp_et", "timestamp", "time", "datetime");
				int iEntryTime  = HeaderIdx(ix, "entrytime", "entry_time", "entry_time_et", "entry_timestamp", "entrytimestamp");
				int iExitTime   = HeaderIdx(ix, "exittime", "exit_time", "exit_time_et", "exit_timestamp", "exittimestamp");

				if (iSignalTime < 0 && iEntryTime < 0)
				{
					lock (gate)
					{
						signals = loaded;
						signalById = byId;
						loadStatus = "Missing SignalTime/EntryTime/timestamp column";
						lastCsvWriteUtc = File.GetLastWriteTimeUtc(resolvedCsvPath);
						selectedSignalId = "";
					}
					return;
				}

				for (int i = 1; i < lines.Length; i++)
				{
					if (string.IsNullOrWhiteSpace(lines[i])) continue;
					List<string> f = SplitCsv(lines[i], delim);
					DateTime signalDt = DateTime.MinValue;
					DateTime entryDt = DateTime.MinValue;
					DateTime exitDt = DateTime.MinValue;

					if (iSignalTime >= 0)
						TryParseTs(Get(f, iSignalTime), out signalDt);
					if (iEntryTime >= 0)
						TryParseTs(Get(f, iEntryTime), out entryDt);

					if (entryDt == DateTime.MinValue)
						entryDt = signalDt;
					if (signalDt == DateTime.MinValue)
						signalDt = entryDt;
					if (entryDt == DateTime.MinValue)
						continue;

					if (iExitTime >= 0)
						TryParseTs(Get(f, iExitTime), out exitDt);

					SignalRow s = new SignalRow();
					s.RowNum = i;
					s.SignalTimeRaw = signalDt;
					s.EntryTimeRaw = entryDt;
					s.ExitTimeRaw = exitDt;
					s.TsRaw = entryDt;
					s.TsChart = entryDt.AddHours(TimestampShiftHours);
					s.TsKey = TsKey(entryDt);
					s.SignalTimeKey = signalDt == DateTime.MinValue ? "" : TsKey(signalDt);
					s.EntryTimeKey = entryDt == DateTime.MinValue ? "" : TsKey(entryDt);
					s.ExitTimeKey = exitDt == DateTime.MinValue ? "" : TsKey(exitDt);

					s.SignalId = Get(f, HeaderIdx(ix, "signal_id", "id", "signalid"));
					if (string.IsNullOrWhiteSpace(s.SignalId)) s.SignalId = "ROW-" + i.ToString(CultureInfo.InvariantCulture);

					s.ModelName = Get(f, HeaderIdx(ix, "modelname", "model_name", "model", "strategy", "setup_name", "setup"));
					s.ModelAlias = Get(f, HeaderIdx(ix, "modelalias", "model_alias", "alias"));
					s.InternalModelId = Get(f, HeaderIdx(ix, "internalmodelid", "internal_model_id", "model_id", "internal_id"));

					s.Type = Get(f, HeaderIdx(ix, "type", "species", "category", "model_name", "modelname"));
					if (string.IsNullOrWhiteSpace(s.Type)) s.Type = s.ModelName;

					s.TypeAbbr = Get(f, HeaderIdx(ix, "type_abbr", "abbr", "typeabbr", "model_alias", "modelalias", "internal_model_id", "internalmodelid", "internalmodel", "model_id")).ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(s.TypeAbbr)) s.TypeAbbr = Safe(s.ModelAlias).ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(s.TypeAbbr)) s.TypeAbbr = Safe(s.InternalModelId).ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(s.TypeAbbr) && s.SignalId.IndexOf('-') > 0)
						s.TypeAbbr = s.SignalId.Substring(0, s.SignalId.IndexOf('-')).ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(s.ModelName)) s.ModelName = s.Type;
					if (string.IsNullOrWhiteSpace(s.ModelAlias)) s.ModelAlias = s.TypeAbbr;

					s.Side = Get(f, HeaderIdx(ix, "side", "direction", "dir")).ToUpperInvariant();
					s.DateEt = Get(f, HeaderIdx(ix, "date_et", "date"));
					s.TimeEt = Get(f, HeaderIdx(ix, "time_et"));
					s.AbsorptionBar = Get(f, HeaderIdx(ix, "absorption_bar_et", "absorption_bar"));
					s.BarNumInDay = ParseInt(Get(f, HeaderIdx(ix, "bar_num_in_day")));

					s.EntryPrice = GetD(f, ix, "entry_price", "entryprice", "price");
					s.StopPrice = GetD(f, ix, "stop_price", "stopprice", "stop");
					s.Target1Price = GetD(f, ix, "target1_price", "target1price", "target_1_price", "target1", "target_1", "t1", "target25price", "target_25_price");
					s.Target2Price = GetD(f, ix, "target2_price", "target2price", "target_2_price", "target2", "target_2", "t2", "target50price", "target_50_price");
					s.ExitPrice = GetD(f, ix, "exit_price", "exitprice");
					s.NetPoints = GetD(f, ix, "net_points", "netpoints", "pnl_points", "points");
					s.Outcome = Get(f, HeaderIdx(ix, "outcome", "result"));
					s.ReviewPriority = Get(f, HeaderIdx(ix, "review_priority", "reviewpriority", "priority"));
					s.LocationContext = Get(f, HeaderIdx(ix, "location", "location_context", "locationcontext", "level_context", "levelcontext"));
					s.CsvVisualGrade = Get(f, HeaderIdx(ix, "visual_grade", "visualgrade", "grade"));
					s.CsvReviewNotes = Get(f, HeaderIdx(ix, "review_notes", "reviewnotes", "notes"));
					s.CsvRejectReason = Get(f, HeaderIdx(ix, "reject_reason", "rejectreason", "failure_reason", "failurereason"));
					s.SigOpen = GetD(f, ix, "sig_open", "open");
					s.SigHigh = GetD(f, ix, "sig_high", "high");
					s.SigLow = GetD(f, ix, "sig_low", "low");
					s.SigClose = GetD(f, ix, "sig_close", "close");
					s.AbsorpHigh = GetD(f, ix, "absorp_high");
					s.AbsorpLow = GetD(f, ix, "absorp_low");
					s.AbsorpClose = GetD(f, ix, "absorp_close");

					s.AbsorptionValue = GetD(f, ix, "absorption_value");
					s.AbsorptionZ = GetD(f, ix, "absorption_value_z");
					s.AbsorptionT = GetD(f, ix, "absorption_value_t");
					s.AbsorptionT2 = GetD(f, ix, "absorption_value_t2");
					s.DeltaSignal = GetD(f, ix, "delta_signalbar");
					s.DeltaAbsorp = GetD(f, ix, "delta_absorpbar");
					s.DeltaZSignal = GetD(f, ix, "delta_z_signalbar");
					s.DeltaZAbsorp = GetD(f, ix, "delta_z_absorpbar");
					s.FlipStrengthZ = GetD(f, ix, "flip_strength_z");
					s.CumDelta5 = GetD(f, ix, "cum_delta_5bar");
					s.CvdSession = GetD(f, ix, "cvd_session");
					s.VolExtremeShare = GetD(f, ix, "vol_at_extreme_share");
					s.AggrVolExtremeShare = GetD(f, ix, "aggr_vol_at_extreme_share");
					s.BarVolume = GetD(f, ix, "bar_volume", "volume");
					s.StackedImbRun = GetD(f, ix, "stacked_imb_run");
					s.DiagImb = GetD(f, ix, "diag_imb");
					s.AtFractalPivot = GetB(f, ix, "at_fractal_pivot");
					s.AtSwingLeg = GetB(f, ix, "at_swing_leg");
					s.Fresh20Extreme = GetB(f, ix, "fresh_20bar_extreme");
					s.SwingLegAtr = GetD(f, ix, "swing_leg_atr");
					s.DistFromVwapAtr = GetD(f, ix, "dist_from_vwap_atr");
					s.Atr14 = GetD(f, ix, "atr_14");
					s.Vix = GetD(f, ix, "vix");
					s.SigBarRange = GetD(f, ix, "sig_bar_range", "range");
					s.Mfe30 = GetD(f, ix, "mfe_30", "mfe30");
					s.Mae30 = GetD(f, ix, "mae_30", "mae30");
					s.Mfe60 = GetD(f, ix, "mfe_60", "mfe60", "mfe");
					s.Mae60 = GetD(f, ix, "mae_60", "mae60", "mae");
					s.Mfe120 = GetD(f, ix, "mfe_120", "mfe120");
					s.Mae120 = GetD(f, ix, "mae_120", "mae120");
					s.BarsToMfe60 = GetD(f, ix, "bars_to_mfe_60", "bars_to_mfe60", "bars_to_mfe");
					s.MoveToEod = GetD(f, ix, "move_to_eod", "eod_move");
					s.MfeMaeRatio60 = GetD(f, ix, "mfe_mae_ratio_60", "mfe_mae_ratio", "rr_60");
					s.IsBigMove100 = GetB(f, ix, "is_big_move_100");
					s.IsCleanTrade = GetB(f, ix, "is_clean_trade");
					s.IsTinyNoise = GetB(f, ix, "is_tiny_noise");
					s.IsHighMae = GetB(f, ix, "is_high_mae");

					loaded.Add(s);
					byId[s.SignalId] = s;
				}

				lock (gate)
				{
					signals = loaded;
					signalById = byId;
					lastCsvWriteUtc = File.GetLastWriteTimeUtc(resolvedCsvPath);
					loadStatus = "Loaded " + loaded.Count.ToString(CultureInfo.InvariantCulture) + " rows";
					if (!string.IsNullOrWhiteSpace(selectedSignalId) && !byId.ContainsKey(selectedSignalId))
						selectedSignalId = "";
				}
			}
			catch (Exception ex)
			{
				lock (gate) loadStatus = "Load error: " + ex.Message;
				try { Print("ReversalSignalReviewLabeler load error: " + ex.ToString()); } catch { }
			}
		}

		private void LoadTags()
		{
			Dictionary<string, TagRow> loaded = new Dictionary<string, TagRow>();
			try
			{
				if (!string.IsNullOrWhiteSpace(tagPath) && File.Exists(tagPath))
				{
					string[] lines = File.ReadAllLines(tagPath);
					if (lines.Length > 0)
					{
						char delim = lines[0].IndexOf('\t') >= 0 ? '\t' : ',';
						List<string> hdr = SplitCsv(lines[0], delim);
						Dictionary<string, int> ix = HeaderMap(hdr);
						int iId = HeaderIdx(ix, "signal_id", "signalid", "id");
						int iGrade = HeaderIdx(ix, "my_grade", "grade", "visual_grade", "visualgrade");
						int iReason = HeaderIdx(ix, "reason", "reject_reason", "rejectreason");
						int iNote = HeaderIdx(ix, "note", "review_notes", "reviewnotes");
						int iUpdated = HeaderIdx(ix, "updated_local", "tagged_at_local", "reviewed_at_local", "reviewedatlocal");
						for (int i = 1; i < lines.Length; i++)
						{
							if (string.IsNullOrWhiteSpace(lines[i])) continue;
							List<string> f = SplitCsv(lines[i], delim);
							string id = Get(f, iId);
							if (string.IsNullOrWhiteSpace(id)) continue;
							TagRow t = new TagRow();
							t.SignalId = id;
							t.Grade = Get(f, iGrade);
							t.Reason = Get(f, iReason);
							t.Note = Get(f, iNote);
							t.UpdatedLocal = Get(f, iUpdated);
							loaded[id] = t;
						}
					}
					lastTagWriteUtc = File.GetLastWriteTimeUtc(tagPath);
				}
				else lastTagWriteUtc = DateTime.MinValue;
			}
			catch { }
			lock (gate) tags = loaded;
		}

		private void WriteTags()
		{
			try
			{
				string dir = Path.GetDirectoryName(tagPath);
				if (!string.IsNullOrWhiteSpace(dir)) Directory.CreateDirectory(dir);

				List<TagRow> rows;
				Dictionary<string, SignalRow> byId;
				lock (gate)
				{
					rows = new List<TagRow>(tags.Values);
					byId = new Dictionary<string, SignalRow>(signalById);
				}

				rows.Sort(delegate(TagRow a, TagRow b)
				{
					SignalRow sa, sb;
					DateTime da = DateTime.MinValue, db = DateTime.MinValue;
					if (byId.TryGetValue(a.SignalId, out sa)) da = sa.TsRaw;
					if (byId.TryGetValue(b.SignalId, out sb)) db = sb.TsRaw;
					int c = da.CompareTo(db);
					if (c != 0) return c;
					return string.Compare(a.SignalId, b.SignalId, StringComparison.OrdinalIgnoreCase);
				});

				StringBuilder sbuf = new StringBuilder();
				sbuf.AppendLine("SignalID,SignalTime,EntryTime,ExitTime,ModelName,ModelAlias,InternalModelID,Side,EntryPrice,StopPrice,Target1Price,Target2Price,ExitPrice,NetPoints,Outcome,ReviewPriority,LocationContext,VisualGrade,RejectReason,ReviewNotes,ReviewedAtLocal,SourceCSV,MFE30,MAE30,MFE60,MAE60,MFE120,MAE120,MFEMaeRatio60,BarsToMFE60,MoveToEOD,IsCleanTrade,IsBigMove100,IsTinyNoise,IsHighMae,AbsorptionValue,AbsorptionZ,FlipStrengthZ,SwingLegATR,DistFromVWAP_ATR");

				for (int i = 0; i < rows.Count; i++)
				{
					TagRow t = rows[i];
					SignalRow s = null;
					byId.TryGetValue(t.SignalId, out s);
					string source = string.IsNullOrWhiteSpace(resolvedCsvPath) ? "" : Path.GetFileName(resolvedCsvPath);

					sbuf.AppendLine(string.Join(",", new string[] {
						Esc(t.SignalId),
						Esc(s == null ? "" : s.SignalTimeKey),
						Esc(s == null ? "" : s.EntryTimeKey),
						Esc(s == null ? "" : s.ExitTimeKey),
						Esc(s == null ? "" : s.ModelName),
						Esc(s == null ? "" : s.ModelAlias),
						Esc(s == null ? "" : s.InternalModelId),
						Esc(s == null ? "" : s.Side),
						Esc(s == null ? "" : F(s.EntryPrice)),
						Esc(s == null ? "" : F(s.StopPrice)),
						Esc(s == null ? "" : F(s.Target1Price)),
						Esc(s == null ? "" : F(s.Target2Price)),
						Esc(s == null ? "" : F(s.ExitPrice)),
						Esc(s == null ? "" : F(s.NetPoints)),
						Esc(s == null ? "" : s.Outcome),
						Esc(s == null ? "" : s.ReviewPriority),
						Esc(s == null ? "" : s.LocationContext),
						Esc(t.Grade),
						Esc(t.Reason),
						Esc(t.Note),
						Esc(t.UpdatedLocal),
						Esc(source),
						Esc(s == null ? "" : F(s.Mfe30)),
						Esc(s == null ? "" : F(s.Mae30)),
						Esc(s == null ? "" : F(s.Mfe60)),
						Esc(s == null ? "" : F(s.Mae60)),
						Esc(s == null ? "" : F(s.Mfe120)),
						Esc(s == null ? "" : F(s.Mae120)),
						Esc(s == null ? "" : F(s.MfeMaeRatio60)),
						Esc(s == null ? "" : F(s.BarsToMfe60)),
						Esc(s == null ? "" : Signed(s.MoveToEod)),
						Esc(s == null ? "" : B(s.IsCleanTrade)),
						Esc(s == null ? "" : B(s.IsBigMove100)),
						Esc(s == null ? "" : B(s.IsTinyNoise)),
						Esc(s == null ? "" : B(s.IsHighMae)),
						Esc(s == null ? "" : F(s.AbsorptionValue)),
						Esc(s == null ? "" : F(s.AbsorptionZ)),
						Esc(s == null ? "" : F(s.FlipStrengthZ)),
						Esc(s == null ? "" : F(s.SwingLegAtr)),
						Esc(s == null ? "" : Signed(s.DistFromVwapAtr))
					}));
				}

				string tmp = tagPath + ".tmp";
				File.WriteAllText(tmp, sbuf.ToString(), new UTF8Encoding(false));
				File.Copy(tmp, tagPath, true);
				try { File.Delete(tmp); } catch { }
				lastTagWriteUtc = File.GetLastWriteTimeUtc(tagPath);
			}
			catch (Exception ex)
			{
				try { Print("ReversalSignalReviewLabeler tag write error: " + ex.Message); } catch { }
			}
		}
		#endregion

		#region Rendering
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			cachedScale = chartScale;

			if (!mouseHooked && ChartPanel != null)
			{
				try
				{
					ChartPanel.MouseLeftButtonDown += OnChartMouseDown;
					ChartPanel.MouseMove += OnChartMouseMove;
					ChartPanel.MouseLeftButtonUp += OnChartMouseUp;
					mouseHooked = true;
				}
				catch { }
			}

			CheckAutoReload();

			SharpDX.Direct2D1.RenderTarget rt = RenderTarget;
			if (rt == null || dwFactory == null || chartControl == null || chartScale == null)
				return;

			lock (hits) hits.Clear();

			try
			{
				float left = 0f, right = 100000f;
				try
				{
					if (ChartPanel != null)
					{
						left = ChartPanel.X;
						right = ChartPanel.X + ChartPanel.W;
					}
				}
				catch { }

				using (SharpDX.DirectWrite.TextFormat labelFormat = new SharpDX.DirectWrite.TextFormat(dwFactory, "Segoe UI", (float)LabelFontSize))
				using (SharpDX.DirectWrite.TextFormat tinyFormat = new SharpDX.DirectWrite.TextFormat(dwFactory, "Segoe UI", 10.5f))
				using (SharpDX.DirectWrite.TextFormat smallFormat = new SharpDX.DirectWrite.TextFormat(dwFactory, "Segoe UI", 11.5f))
				using (SharpDX.DirectWrite.TextFormat titleFormat = new SharpDX.DirectWrite.TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.SemiBold, SharpDX.DirectWrite.FontStyle.Normal, SharpDX.DirectWrite.FontStretch.Normal, 13.5f))
				{
					RenderSignals(rt, labelFormat, left, right);

					if (ShowDashboard)
						DrawDashboard(rt, titleFormat, smallFormat, tinyFormat);
				}
			}
			catch
			{
				// Never throw from OnRender.
			}
		}

		private void RenderSignals(SharpDX.Direct2D1.RenderTarget rt, SharpDX.DirectWrite.TextFormat tf, float left, float right)
		{
			List<SignalRow> snap;
			Dictionary<string, TagRow> tagSnap;
			lock (gate)
			{
				snap = new List<SignalRow>(signals);
				tagSnap = new Dictionary<string, TagRow>(tags);
			}

			int visible = 0;
			int filtered = 0;
			float marker = (float)MarkerSize;

			using (SharpDX.Direct2D1.SolidColorBrush longBrush = NewBrush(rt, 105, 255, 205, 1.0f))
			using (SharpDX.Direct2D1.SolidColorBrush shortBrush = NewBrush(rt, 255, 107, 150, 1.0f))
			using (SharpDX.Direct2D1.SolidColorBrush cleanBrush = NewBrush(rt, 121, 255, 147, 0.94f))
			using (SharpDX.Direct2D1.SolidColorBrush bigBrush = NewBrush(rt, 255, 218, 116, 0.96f))
			using (SharpDX.Direct2D1.SolidColorBrush problemBrush = NewBrush(rt, 255, 92, 120, 0.94f))
			using (SharpDX.Direct2D1.SolidColorBrush neutralBrush = NewBrush(rt, 145, 164, 186, 0.92f))
			using (SharpDX.Direct2D1.SolidColorBrush taggedBrush = NewBrush(rt, 247, 212, 117, 1.0f))
			using (SharpDX.Direct2D1.SolidColorBrush chipBrush = NewBrush(rt, 15, 34, 48, 0.88f))
			using (SharpDX.Direct2D1.SolidColorBrush chipBorder = NewBrush(rt, 121, 255, 205, 0.24f))
			using (SharpDX.Direct2D1.SolidColorBrush textBrush = NewBrush(rt, 242, 250, 255, 0.95f))
			using (SharpDX.Direct2D1.SolidColorBrush lineBrush = NewBrush(rt, 121, 255, 205, 0.36f))
			{
				for (int i = 0; i < snap.Count; i++)
				{
					SignalRow s = snap[i];
					if (!PassesFilters(s)) continue;

					TagRow existingTag = null;
					bool taggedForFilter = tagSnap.TryGetValue(s.SignalId, out existingTag);
					if (ShowOnlyUnreviewed && taggedForFilter) continue;
					if (!PassesGradeFilter(existingTag)) continue;

					filtered++;

					int x;
					try { x = ChartControl.GetXByTime(s.TsChart); } catch { continue; }
					if (x < left - 90 || x > right + 90) continue;

					if (MaxVisibleSignals > 0 && visible >= MaxVisibleSignals) continue;
					visible++;

					double anchor = GetAnchorPrice(s);
					if (!Valid(anchor)) continue;

					float y;
					try { y = cachedScale.GetYByValue(anchor); } catch { continue; }

					bool isLong = string.Equals(s.Side, "LONG", StringComparison.OrdinalIgnoreCase);
					SharpDX.Direct2D1.Brush fill = OutcomeBrush(s, cleanBrush, bigBrush, problemBrush, neutralBrush);
					SharpDX.Direct2D1.Brush outline = isLong ? (SharpDX.Direct2D1.Brush)longBrush : (SharpDX.Direct2D1.Brush)shortBrush;
					bool tagged = tagSnap.ContainsKey(s.SignalId);
					bool selected = !string.IsNullOrWhiteSpace(selectedSignalId) && string.Equals(selectedSignalId, s.SignalId, StringComparison.OrdinalIgnoreCase);

					if (ShowStopLines || ShowTargetLines)
						DrawRiskRewardLines(rt, s, isLong, x, left, right, lineBrush, roseBrush, mintBrush, bigBrush);

					DrawSignalMarker(rt, isLong, x, y, marker, fill, outline, tagged ? taggedBrush : null, selected);

					Hit h = new Hit();
					h.Cx = x; h.Cy = y; h.R = marker + 8f; h.SignalId = s.SignalId;
					lock (hits) hits.Add(h);

					if (ShowTextLabels)
					{
						TagRow tag = null;
						tagSnap.TryGetValue(s.SignalId, out tag);
						string text = BuildChartLabel(s, tag);
						DrawSignalLabel(rt, tf, text, x, y, marker, isLong, chipBrush, chipBorder, textBrush, lineBrush);
					}
				}
			}

			lastVisibleCount = visible;
			lastFilteredCount = filtered;
		}

		private SharpDX.Direct2D1.Brush OutcomeBrush(SignalRow s, SharpDX.Direct2D1.Brush clean, SharpDX.Direct2D1.Brush big, SharpDX.Direct2D1.Brush problem, SharpDX.Direct2D1.Brush neutral)
		{
			if (s.IsCleanTrade) return clean;
			if (s.IsBigMove100) return big;
			if (s.IsHighMae || s.IsTinyNoise) return problem;
			return neutral;
		}

		private void DrawRiskRewardLines(SharpDX.Direct2D1.RenderTarget rt, SignalRow s, bool isLong, float x1, float left, float right,
			SharpDX.Direct2D1.Brush baseBrush, SharpDX.Direct2D1.Brush stopBrush, SharpDX.Direct2D1.Brush targetBrush, SharpDX.Direct2D1.Brush target2Brush)
		{
			float x2 = GetLineEndX(s, x1, right);

			if (ShowStopLines && Valid(s.StopPrice))
				DrawPriceLine(rt, x1, x2, s.StopPrice, stopBrush, 1.5f);

			if (ShowTargetLines)
			{
				if (Valid(s.Target1Price))
					DrawPriceLine(rt, x1, x2, s.Target1Price, targetBrush, 1.35f);
				if (Valid(s.Target2Price))
					DrawPriceLine(rt, x1, x2, s.Target2Price, target2Brush, 1.35f);

				if (Valid(s.EntryPrice) && fixedTargetPointsArr != null)
				{
					for (int i = 0; i < fixedTargetPointsArr.Length; i++)
					{
						double pts = Math.Abs(fixedTargetPointsArr[i]);
						if (pts <= 0) continue;
						double price = s.EntryPrice + (isLong ? pts : -pts);
						DrawPriceLine(rt, x1, x2, price, targetBrush, 0.75f);
					}
				}
			}
		}

		private float GetLineEndX(SignalRow s, float x1, float right)
		{
			// This is intentionally pixel-based for compile stability across NT8 builds.
			// The LineForwardBars input is treated as an approximate visual length.
			float x2 = x1 + Math.Max(40f, LineForwardBars * 7f);
			return Math.Min(x2, right + 120f);
		}

		private void DrawPriceLine(SharpDX.Direct2D1.RenderTarget rt, float x1, float x2, double price, SharpDX.Direct2D1.Brush brush, float width)
		{
			if (cachedScale == null || !Valid(price) || brush == null) return;
			try
			{
				float y = cachedScale.GetYByValue(price);
				rt.DrawLine(new SharpDX.Vector2(x1, y), new SharpDX.Vector2(x2, y), brush, width);
			}
			catch { }
		}

		private void DrawSignalMarker(SharpDX.Direct2D1.RenderTarget rt, bool up, float cx, float cy, float s,
			SharpDX.Direct2D1.Brush fill, SharpDX.Direct2D1.Brush outline, SharpDX.Direct2D1.Brush taggedOutline, bool selected)
		{
			float hs = s / 2f;
			float[] nx = { 0f, 0.86f, -0.86f };
			float[] ny = up ? new float[] { -0.9f, 0.7f, 0.7f } : new float[] { 0.9f, -0.7f, -0.7f };

			using (SharpDX.Direct2D1.PathGeometry geo = new SharpDX.Direct2D1.PathGeometry(rt.Factory))
			{
				using (SharpDX.Direct2D1.GeometrySink sink = geo.Open())
				{
					sink.BeginFigure(new SharpDX.Vector2(cx + nx[0] * hs, cy + ny[0] * hs), SharpDX.Direct2D1.FigureBegin.Filled);
					sink.AddLine(new SharpDX.Vector2(cx + nx[1] * hs, cy + ny[1] * hs));
					sink.AddLine(new SharpDX.Vector2(cx + nx[2] * hs, cy + ny[2] * hs));
					sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
					sink.Close();
				}

				if (selected)
				{
					using (SharpDX.Direct2D1.SolidColorBrush glow = NewBrush(rt, 121, 255, 205, 0.22f))
						rt.DrawGeometry(geo, glow, 8.0f);
				}

				rt.FillGeometry(geo, fill);
				if (taggedOutline != null) rt.DrawGeometry(geo, taggedOutline, 4.2f);
				if (outline != null) rt.DrawGeometry(geo, outline, 2.3f);
			}
		}

		private void DrawSignalLabel(SharpDX.Direct2D1.RenderTarget rt, SharpDX.DirectWrite.TextFormat tf, string text, float markerX, float markerY, float markerSize, bool isLong,
			SharpDX.Direct2D1.Brush chipBrush, SharpDX.Direct2D1.Brush chipBorder, SharpDX.Direct2D1.Brush textBrush, SharpDX.Direct2D1.Brush lineBrush)
		{
			if (string.IsNullOrEmpty(text)) return;

			SharpDX.DirectWrite.TextLayout tl = null;
			try
			{
				float maxW = 295f;
				tl = new SharpDX.DirectWrite.TextLayout(dwFactory, text, tf, maxW, 170f);
				float w = Math.Max(10f, tl.Metrics.Width);
				float h = Math.Max(10f, tl.Metrics.Height);
				float padX = 7f;
				float padY = 5f;
				float x = markerX + markerSize * 0.60f + LabelOffsetPixels;
				float y = isLong ? markerY + LabelOffsetPixels : markerY - h - LabelOffsetPixels;

				if (ShowLeaderLine && lineBrush != null)
				{
					float lineY = isLong ? y + 7f : y + h - 7f;
					rt.DrawLine(new SharpDX.Vector2(markerX, markerY), new SharpDX.Vector2(x - 3f, lineY), lineBrush, 1.15f);
				}

				DrawRounded(rt, new SharpDX.RectangleF(x - padX, y - padY, w + padX * 2f, h + padY * 2f), 8f, chipBrush, true, 0);
				DrawRounded(rt, new SharpDX.RectangleF(x - padX, y - padY, w + padX * 2f, h + padY * 2f), 8f, chipBorder, false, 0.9f);
				rt.DrawTextLayout(new SharpDX.Vector2(x, y), tl, textBrush);
			}
			catch { }
			finally { if (tl != null) tl.Dispose(); }
		}

		private string BuildChartLabel(SignalRow s, TagRow tag)
		{
			StringBuilder b = new StringBuilder();
			string model = !string.IsNullOrWhiteSpace(s.ModelAlias) ? s.ModelAlias : (!string.IsNullOrWhiteSpace(s.TypeAbbr) ? s.TypeAbbr : s.ModelName);
			b.Append(Safe(model));
			if (!string.IsNullOrWhiteSpace(s.Side)) b.Append(" ").Append(TitleCase(s.Side));
			if (ShowOutcomePnl && (Valid(s.NetPoints) || !string.IsNullOrWhiteSpace(s.Outcome)))
				b.AppendLine().Append("Outcome ").Append(Safe(s.Outcome)).Append(" ").Append(Valid(s.NetPoints) ? Signed(s.NetPoints) + " pts" : "");
			if (tag != null && !string.IsNullOrWhiteSpace(tag.Grade))
				b.AppendLine().Append(tag.Grade);
			return TrimEndLines(b.ToString());
		}

		private void DrawDashboard(SharpDX.Direct2D1.RenderTarget rt, SharpDX.DirectWrite.TextFormat titleFormat, SharpDX.DirectWrite.TextFormat smallFormat, SharpDX.DirectWrite.TextFormat tinyFormat)
		{
			SignalRow selected = null;
			TagRow selectedTag = null;
			int total = 0, taggedCount = 0, visible = lastVisibleCount, filtered = lastFilteredCount;
			string status = "";
			string csvName = "";
			lock (gate)
			{
				total = signals.Count;
				taggedCount = tags.Count;
				status = loadStatus;
				csvName = string.IsNullOrWhiteSpace(resolvedCsvPath) ? "" : Path.GetFileName(resolvedCsvPath);
				if (!string.IsNullOrWhiteSpace(selectedSignalId))
				{
					signalById.TryGetValue(selectedSignalId, out selected);
					tags.TryGetValue(selectedSignalId, out selectedTag);
				}
			}

			float w = Math.Max(300, DashboardWidth);
			float h = Math.Max(145, DashboardHeight);
			float x = GetDashboardX(w);
			float y = GetDashboardY(h);
			if (dashboardDragging)
			{
				x = dragX - dragOffsetX;
				y = dragY - dragOffsetY;
			}

			lastDashboardRect = new SharpDX.RectangleF(x, y, w, h);
			lastDashboardHeaderRect = new SharpDX.RectangleF(x, y, w, 35f);

			SharpDX.Color4 navy1 = C4(18, 46, 67, 0.92f);
			SharpDX.Color4 navy2 = C4(10, 25, 38, 0.94f);
			SharpDX.Color4 mint = C4(121, 255, 205, 1f);
			SharpDX.Color4 mintSoft = C4(121, 255, 205, 0.34f);
			SharpDX.Color4 gold = C4(247, 212, 117, 1f);
			SharpDX.Color4 white = C4(244, 250, 255, 1f);
			SharpDX.Color4 muted = C4(176, 198, 212, 0.92f);
			SharpDX.Color4 darkChip = C4(11, 32, 47, 0.86f);
			SharpDX.Color4 rose = C4(255, 107, 150, 1f);

			SharpDX.Direct2D1.GradientStop[] bgStopsArray = new SharpDX.Direct2D1.GradientStop[]
			{
				new SharpDX.Direct2D1.GradientStop { Position = 0.0f, Color = navy1 },
				new SharpDX.Direct2D1.GradientStop { Position = 1.0f, Color = navy2 }
			};

			using (SharpDX.Direct2D1.GradientStopCollection bgStops = new SharpDX.Direct2D1.GradientStopCollection(rt, bgStopsArray))
			using (SharpDX.Direct2D1.LinearGradientBrush bg = new SharpDX.Direct2D1.LinearGradientBrush(rt,
				new SharpDX.Direct2D1.LinearGradientBrushProperties
				{
					StartPoint = new SharpDX.Vector2(lastDashboardRect.Left, lastDashboardRect.Top),
					EndPoint = new SharpDX.Vector2(lastDashboardRect.Right, lastDashboardRect.Bottom)
				},
				bgStops))
			using (SharpDX.Direct2D1.SolidColorBrush shadow = new SharpDX.Direct2D1.SolidColorBrush(rt, C4(0, 0, 0, 0.30f)))
			using (SharpDX.Direct2D1.SolidColorBrush glow = new SharpDX.Direct2D1.SolidColorBrush(rt, C4(121, 255, 205, 0.16f)))
			using (SharpDX.Direct2D1.SolidColorBrush border = new SharpDX.Direct2D1.SolidColorBrush(rt, mintSoft))
			using (SharpDX.Direct2D1.SolidColorBrush text = new SharpDX.Direct2D1.SolidColorBrush(rt, white))
			using (SharpDX.Direct2D1.SolidColorBrush mutedBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, muted))
			using (SharpDX.Direct2D1.SolidColorBrush goldBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, gold))
			using (SharpDX.Direct2D1.SolidColorBrush mintBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, mint))
			using (SharpDX.Direct2D1.SolidColorBrush roseBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, rose))
			using (SharpDX.Direct2D1.SolidColorBrush chipBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, darkChip))
			{
				DrawRounded(rt, Inflate(lastDashboardRect, 3f, 3f), 17f, glow, true, 0);
				DrawRounded(rt, Offset(lastDashboardRect, 0f, 3f), 16f, shadow, true, 0);
				DrawRounded(rt, lastDashboardRect, 16f, bg, true, 0);
				DrawRounded(rt, lastDashboardRect, 16f, border, false, 1.2f);

				// Header
				DrawDot(rt, x + 16f, y + 18f, selected == null ? mint : (IsLong(selected) ? mint : rose));
				DrawClippedText(rt, "Signal Review", titleFormat, new SharpDX.RectangleF(x + 28f, y + 9f, 170f, 22f), text);
				DrawChip(rt, x + w - 126f, y + 8f, 108f, 21f, ModeSummary(total, taggedCount), chipBrush, selected == null ? mintBrush : goldBrush, tinyFormat);

				// Separator
				using (SharpDX.Direct2D1.SolidColorBrush sep = new SharpDX.Direct2D1.SolidColorBrush(rt, C4(190, 225, 235, 0.14f)))
					rt.DrawLine(new SharpDX.Vector2(x + 16f, y + 38f), new SharpDX.Vector2(x + w - 16f, y + 38f), sep, 1f);

				float rowY = y + 46f;
				if (selected == null)
				{
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Status", status, goldBrush, text, w - 36f);
					rowY += 25f;
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Action", ModText() + " a marker to label / review MFE-MAE", goldBrush, mintBrush, w - 36f);
					rowY += 25f;
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Visible", visible.ToString(CultureInfo.InvariantCulture) + " visible / " + filtered.ToString(CultureInfo.InvariantCulture) + " filtered / " + total.ToString(CultureInfo.InvariantCulture) + " total", goldBrush, text, w - 36f);
					rowY += 25f;
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "File", string.IsNullOrWhiteSpace(csvName) ? "No CSV loaded" : csvName, goldBrush, mutedBrush, w - 36f);
				}
				else
				{
					string time = selected.TsRaw.ToString("h:mm tt", CultureInfo.InvariantCulture);
					string model = !string.IsNullOrWhiteSpace(selected.ModelName) ? selected.ModelName : (!string.IsNullOrWhiteSpace(selected.Type) ? selected.Type : selected.TypeAbbr);
					string sideType = time + "  " + TitleCase(selected.Side) + "  " + Safe(model);
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Selected", sideType, goldBrush, IsLong(selected) ? mintBrush : roseBrush, w - 36f);
					rowY += 23f;

					string mfeMae = "30m +" + F(selected.Mfe30) + " / -" + F(selected.Mae30)
						+ "    60m +" + F(selected.Mfe60) + " / -" + F(selected.Mae60)
						+ "    R " + F(selected.MfeMaeRatio60);
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "MFE / MAE", mfeMae, goldBrush, text, w - 36f);
					rowY += 23f;

					string risk = "Entry " + F(selected.EntryPrice) + "  Stop " + F(selected.StopPrice)
						+ "  T1 " + F(selected.Target1Price) + "  T2 " + F(selected.Target2Price);
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Risk", risk, goldBrush, text, w - 36f);
					rowY += 23f;

					string location = BuildLocationSummary(selected);
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Location", location, goldBrush, text, w - 36f);
					rowY += 23f;

					string outcome = ShowOutcomePnl
						? ("Outcome " + Safe(selected.Outcome) + "  " + (Valid(selected.NetPoints) ? Signed(selected.NetPoints) + " pts" : ""))
						: "Outcome hidden for structural review";
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Blind Review", outcome, goldBrush, ShowOutcomePnl ? text : mutedBrush, w - 36f);
					rowY += 23f;

					string grade = selectedTag == null || string.IsNullOrWhiteSpace(selectedTag.Grade) ? "Unlabeled" : selectedTag.Grade;
					string reason = selectedTag == null || string.IsNullOrWhiteSpace(selectedTag.Reason) ? "Ctrl+Click marker to grade + reason" : selectedTag.Reason;
					DrawLabelValue(rt, tinyFormat, smallFormat, x + 18f, rowY, "Grade", grade + "  •  " + reason, goldBrush, selectedTag == null ? mutedBrush : mintBrush, w - 36f);
				}

				// Footer status
				float footY = y + h - 24f;
				string footer = "Tagged " + taggedCount.ToString(CultureInfo.InvariantCulture)
					+ " / " + total.ToString(CultureInfo.InvariantCulture)
					+ "     " + (EnableShiftDragDashboard ? "Shift+drag header to move" : "Dashboard locked");
				DrawClippedText(rt, footer, tinyFormat, new SharpDX.RectangleF(x + 18f, footY, w - 36f, 18f), mutedBrush);
			}
		}

		private string ModeSummary(int total, int tagged)
		{
			if (total <= 0) return "NO CSV";
			return tagged.ToString(CultureInfo.InvariantCulture) + " / " + total.ToString(CultureInfo.InvariantCulture) + " TAGGED";
		}

		private string ModText()
		{
			return TagClickModifier == RsrReviewClickMod.None ? "Click" : TagClickModifier.ToString() + "+Click";
		}

		private string BuildLocationSummary(SignalRow s)
		{
			if (!string.IsNullOrWhiteSpace(s.LocationContext))
				return s.LocationContext;

			List<string> parts = new List<string>();
			if (Valid(s.SwingLegAtr)) parts.Add("Swing " + F(s.SwingLegAtr) + " ATR");
			if (Valid(s.DistFromVwapAtr)) parts.Add("VWAP " + Signed(s.DistFromVwapAtr) + " ATR");
			if (s.Fresh20Extreme) parts.Add("fresh 20-bar extreme");
			if (s.AtSwingLeg) parts.Add("swing leg");
			if (s.AtFractalPivot) parts.Add("fractal pivot");
			if (parts.Count == 0) return "No location fields in CSV";
			return string.Join("  •  ", parts.ToArray());
		}

		private void DrawLabelValue(SharpDX.Direct2D1.RenderTarget rt, SharpDX.DirectWrite.TextFormat labelFormat, SharpDX.DirectWrite.TextFormat valueFormat,
			float x, float y, string label, string value, SharpDX.Direct2D1.Brush labelBrush, SharpDX.Direct2D1.Brush valueBrush, float maxW)
		{
			DrawClippedText(rt, label, labelFormat, new SharpDX.RectangleF(x, y + 2f, 84f, 18f), labelBrush);
			DrawClippedText(rt, value, valueFormat, new SharpDX.RectangleF(x + 88f, y, maxW - 88f, 22f), valueBrush);
		}

		private void DrawChip(SharpDX.Direct2D1.RenderTarget rt, float x, float y, float w, float h, string text,
			SharpDX.Direct2D1.Brush fill, SharpDX.Direct2D1.Brush stroke, SharpDX.DirectWrite.TextFormat tf)
		{
			SharpDX.RectangleF r = new SharpDX.RectangleF(x, y, w, h);
			DrawRounded(rt, r, h / 2f, fill, true, 0);
			DrawRounded(rt, r, h / 2f, stroke, false, 0.85f);
			tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
			DrawClippedText(rt, text, tf, new SharpDX.RectangleF(x + 5f, y + 3f, w - 10f, h - 4f), stroke);
			tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
		}

		private void DrawDot(SharpDX.Direct2D1.RenderTarget rt, float x, float y, SharpDX.Color4 c)
		{
			using (SharpDX.Direct2D1.SolidColorBrush glow = new SharpDX.Direct2D1.SolidColorBrush(rt, new SharpDX.Color4(c.Red, c.Green, c.Blue, 0.22f)))
			using (SharpDX.Direct2D1.SolidColorBrush dot = new SharpDX.Direct2D1.SolidColorBrush(rt, c))
			{
				rt.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x, y), 8.2f, 8.2f), glow);
				rt.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x, y), 4.2f, 4.2f), dot);
			}
		}

		private void DrawClippedText(SharpDX.Direct2D1.RenderTarget rt, string text, SharpDX.DirectWrite.TextFormat tf, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush)
		{
			if (text == null) text = "";
			SharpDX.DirectWrite.TextLayout tl = null;
			try
			{
				rt.PushAxisAlignedClip(rect, SharpDX.Direct2D1.AntialiasMode.PerPrimitive);
				tl = new SharpDX.DirectWrite.TextLayout(dwFactory, text, tf, rect.Width, rect.Height);
				rt.DrawTextLayout(new SharpDX.Vector2(rect.X, rect.Y), tl, brush);
			}
			catch { }
			finally
			{
				try { rt.PopAxisAlignedClip(); } catch { }
				if (tl != null) tl.Dispose();
			}
		}

		private SharpDX.Direct2D1.SolidColorBrush NewBrush(SharpDX.Direct2D1.RenderTarget rt, byte r, byte g, byte b, float a)
		{
			return new SharpDX.Direct2D1.SolidColorBrush(rt, C4(r, g, b, a));
		}

		private SharpDX.Color4 C4(byte r, byte g, byte b, float a)
		{
			return new SharpDX.Color4(r / 255f, g / 255f, b / 255f, a);
		}

		private void DrawRounded(SharpDX.Direct2D1.RenderTarget rt, SharpDX.RectangleF rect, float radius, SharpDX.Direct2D1.Brush brush, bool fill, float strokeWidth)
		{
			SharpDX.Direct2D1.RoundedRectangle rr = new SharpDX.Direct2D1.RoundedRectangle
			{
				Rect = rect,
				RadiusX = radius,
				RadiusY = radius
			};

			if (fill)
				rt.FillRoundedRectangle(rr, brush);
			else
				rt.DrawRoundedRectangle(rr, brush, strokeWidth);
		}

		private SharpDX.RectangleF Inflate(SharpDX.RectangleF rect, float x, float y)
		{
			return new SharpDX.RectangleF(rect.X - x, rect.Y - y, rect.Width + x * 2f, rect.Height + y * 2f);
		}

		private SharpDX.RectangleF Offset(SharpDX.RectangleF rect, float x, float y)
		{
			return new SharpDX.RectangleF(rect.X + x, rect.Y + y, rect.Width, rect.Height);
		}

		private float GetDashboardX(float w)
		{
			if (ChartPanel == null) return DashboardMarginX;
			if (DashboardAnchor == RsrReviewDashboardAnchor.TopLeft || DashboardAnchor == RsrReviewDashboardAnchor.BottomLeft)
				return (float)ChartPanel.X + DashboardMarginX;
			return (float)(ChartPanel.X + ChartPanel.W) - w - DashboardMarginX;
		}

		private float GetDashboardY(float h)
		{
			if (ChartPanel == null) return DashboardMarginY;
			if (DashboardAnchor == RsrReviewDashboardAnchor.TopLeft || DashboardAnchor == RsrReviewDashboardAnchor.TopRight)
				return (float)ChartPanel.Y + DashboardMarginY;
			return (float)(ChartPanel.Y + ChartPanel.H) - h - DashboardMarginY;
		}
		#endregion

		#region Click/drag handling
		private bool TagModHeld()
		{
			switch (TagClickModifier)
			{
				case RsrReviewClickMod.Ctrl:  return (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control;
				case RsrReviewClickMod.Alt:   return (Keyboard.Modifiers & ModifierKeys.Alt) == ModifierKeys.Alt;
				case RsrReviewClickMod.Shift: return (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift;
				default: return true;
			}
		}

		private bool ShiftHeld()
		{
			return (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift;
		}

		private void OnChartMouseDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (ChartControl == null || cachedScale == null) return;

				System.Windows.Point p = e.GetPosition(ChartControl);
				int devX, devY;
				ToDevicePixels(p, out devX, out devY);

				if (ShowDashboard && EnableShiftDragDashboard && ShiftHeld() && Contains(lastDashboardHeaderRect, devX, devY))
				{
					dashboardDragging = true;
					dragX = devX;
					dragY = devY;
					dragOffsetX = devX - lastDashboardRect.X;
					dragOffsetY = devY - lastDashboardRect.Y;
					e.Handled = true;
					RefreshChart();
					return;
				}

				if (!EnableTagging || !TagModHeld()) return;

				Hit hit = FindHit(devX, devY);
				if (hit == null || string.IsNullOrWhiteSpace(hit.SignalId)) return;

				selectedSignalId = hit.SignalId;
				OpenTagPopup(hit.SignalId);
				e.Handled = true;
				RefreshChart();
			}
			catch { }
		}

		private void OnChartMouseMove(object sender, MouseEventArgs e)
		{
			try
			{
				if (!dashboardDragging || ChartControl == null) return;
				System.Windows.Point p = e.GetPosition(ChartControl);
				int devX, devY;
				ToDevicePixels(p, out devX, out devY);
				dragX = devX;
				dragY = devY;
				e.Handled = true;
				RefreshChart();
			}
			catch { }
		}

		private void OnChartMouseUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (!dashboardDragging || ChartControl == null) return;
				System.Windows.Point p = e.GetPosition(ChartControl);
				int devX, devY;
				ToDevicePixels(p, out devX, out devY);
				SnapDashboardToCorner(devX, devY);
				dashboardDragging = false;
				e.Handled = true;
				RefreshChart();
			}
			catch { dashboardDragging = false; }
		}

		private void SnapDashboardToCorner(int devX, int devY)
		{
			if (ChartPanel == null) return;
			float midX = (float)(ChartPanel.X + ChartPanel.W / 2.0);
			float midY = (float)(ChartPanel.Y + ChartPanel.H / 2.0);
			bool left = devX < midX;
			bool top = devY < midY;

			if (left && top) DashboardAnchor = RsrReviewDashboardAnchor.TopLeft;
			else if (!left && top) DashboardAnchor = RsrReviewDashboardAnchor.TopRight;
			else if (left && !top) DashboardAnchor = RsrReviewDashboardAnchor.BottomLeft;
			else DashboardAnchor = RsrReviewDashboardAnchor.BottomRight;
		}

		private bool Contains(SharpDX.RectangleF r, int x, int y)
		{
			return x >= r.Left && x <= r.Right && y >= r.Top && y <= r.Bottom;
		}

		private Hit FindHit(int devX, int devY)
		{
			Hit hit = null;
			float best = float.MaxValue;
			lock (hits)
			{
				for (int i = 0; i < hits.Count; i++)
				{
					Hit h = hits[i];
					float dx = h.Cx - devX;
					float dy = h.Cy - devY;
					float d = (float)Math.Sqrt(dx * dx + dy * dy);
					if (d < h.R + 8f && d < best)
					{
						best = d;
						hit = h;
					}
				}
			}
			return hit;
		}

		private void ToDevicePixels(System.Windows.Point p, out int devX, out int devY)
		{
			double sx = 1.0, sy = 1.0;
			try
			{
				PresentationSource src = PresentationSource.FromVisual(ChartControl);
				if (src != null && src.CompositionTarget != null)
				{
					Matrix m = src.CompositionTarget.TransformToDevice;
					sx = m.M11; sy = m.M22;
				}
			}
			catch { }
			devX = (int)(p.X * sx);
			devY = (int)(p.Y * sy);
		}
		#endregion

		#region Popup/tagging
		private void OpenTagPopup(string signalId)
		{
			SignalRow s = null;
			TagRow existing = null;
			lock (gate)
			{
				signalById.TryGetValue(signalId, out s);
				tags.TryGetValue(signalId, out existing);
			}
			if (s == null) return;

			string details = BuildPopupDetails(s, existing);
			string curGrade = existing == null ? "" : existing.Grade;
			string curReason = existing == null ? "" : existing.Reason;
			string curNote = existing == null ? "" : existing.Note;

			ChartControl.Dispatcher.InvokeAsync(delegate()
			{
				CloseTagWindow();
				ReversalSignalReviewWindow win = new ReversalSignalReviewWindow(signalId, details, curGrade, curReason, curNote, gradeArr, reasonArr,
					delegate(string grade, string reason, string note, bool delete)
					{
						lock (gate)
						{
							if (delete)
							{
								if (tags.ContainsKey(signalId)) tags.Remove(signalId);
							}
							else
							{
								TagRow t = new TagRow();
								t.SignalId = signalId;
								t.Grade = grade;
								t.Reason = reason;
								t.Note = note;
								t.UpdatedLocal = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
								tags[signalId] = t;
							}
							WriteTags();
						}
						RefreshChart();
					});
				try { win.Owner = Window.GetWindow(ChartControl); } catch { }
				win.Closed += delegate { if (tagWindow == win) tagWindow = null; };
				tagWindow = win;
				win.Show();
			});
		}

		private void CloseTagWindow()
		{
			try
			{
				if (tagWindow != null)
				{
					Window w = tagWindow;
					tagWindow = null;
					w.Dispatcher.InvokeAsync(delegate() { try { w.Close(); } catch { } });
				}
			}
			catch { }
		}

		private void RefreshChart()
		{
			try
			{
				if (ChartControl != null)
					ChartControl.Dispatcher.InvokeAsync(delegate() { try { ForceRefresh(); } catch { try { ChartControl.InvalidateVisual(); } catch { } } });
			}
			catch { }
		}

		private string BuildPopupDetails(SignalRow s, TagRow tag)
		{
			StringBuilder b = new StringBuilder();
			string model = !string.IsNullOrWhiteSpace(s.ModelName) ? s.ModelName : (!string.IsNullOrWhiteSpace(s.Type) ? s.Type : s.TypeAbbr);
			b.AppendLine(s.SignalId + "  •  " + TitleCase(s.Side) + "  •  " + Safe(model));
			if (!string.IsNullOrWhiteSpace(s.InternalModelId) || !string.IsNullOrWhiteSpace(s.ModelAlias))
				b.AppendLine("Model ID: " + Safe(s.InternalModelId) + "   Alias: " + Safe(s.ModelAlias));
			b.AppendLine("Signal Time: " + (s.SignalTimeRaw == DateTime.MinValue ? "na" : s.SignalTimeRaw.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)));
			b.AppendLine("Entry Time:  " + s.EntryTimeRaw.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture));
			if (s.ExitTimeRaw != DateTime.MinValue)
				b.AppendLine("Exit Time:   " + s.ExitTimeRaw.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture));
			b.AppendLine("Entry: " + F(s.EntryPrice) + "    Stop: " + F(s.StopPrice) + "    T1/T2: " + F(s.Target1Price) + " / " + F(s.Target2Price));
			if (ShowOutcomePnl)
				b.AppendLine("Outcome: " + Safe(s.Outcome) + "    Net Points: " + (Valid(s.NetPoints) ? Signed(s.NetPoints) : "na") + "    Exit: " + F(s.ExitPrice));
			else
				b.AppendLine("Outcome/PnL: hidden for structural review");
			b.AppendLine("");
			b.AppendLine("MFE / MAE");
			b.AppendLine("30m: +" + F(s.Mfe30) + " / -" + F(s.Mae30));
			b.AppendLine("60m: +" + F(s.Mfe60) + " / -" + F(s.Mae60) + "     R: " + F(s.MfeMaeRatio60) + "     bars to MFE: " + F(s.BarsToMfe60));
			b.AppendLine("120m: +" + F(s.Mfe120) + " / -" + F(s.Mae120) + "     EOD: " + Signed(s.MoveToEod));
			b.AppendLine("");
			b.AppendLine("Context");
			b.AppendLine("Location: " + BuildLocationSummary(s));
			b.AppendLine("Priority: " + Safe(s.ReviewPriority) + "    CSV Grade/Reason: " + Safe(s.CsvVisualGrade) + " / " + Safe(s.CsvRejectReason));
			b.AppendLine("AbsZ " + F(s.AbsorptionZ) + "  •  Flip " + F(s.FlipStrengthZ) + "  •  DeltaZ " + F(s.DeltaZSignal) + "/" + F(s.DeltaZAbsorp));
			b.AppendLine("Swing " + F(s.SwingLegAtr) + " ATR  •  VWAP " + Signed(s.DistFromVwapAtr) + " ATR  •  Range " + F(s.SigBarRange));
			b.AppendLine("Flags: " + Flags(s));
			if (tag != null && (!string.IsNullOrWhiteSpace(tag.Grade) || !string.IsNullOrWhiteSpace(tag.Reason)))
			{
				b.AppendLine("");
				b.AppendLine("Current label: " + tag.Grade + "  •  " + tag.Reason);
			}
			return b.ToString();
		}

		#endregion

		#region Label text/filtering
		private string Flags(SignalRow s)
		{
			List<string> f = new List<string>();
			if (s.IsCleanTrade) f.Add("CLEAN");
			if (s.IsBigMove100) f.Add("BIG100");
			if (s.IsTinyNoise) f.Add("NOISE");
			if (s.IsHighMae) f.Add("HI-MAE");
			if (s.AtSwingLeg) f.Add("SWING");
			if (s.Fresh20Extreme) f.Add("NEW20");
			if (s.AtFractalPivot) f.Add("FRAC");
			if (f.Count == 0) return "none";
			return string.Join(" ", f.ToArray());
		}

		private bool PassesGradeFilter(TagRow tag)
		{
			if (gradeFilterArr == null || gradeFilterArr.Length == 0)
				return true;

			string g = tag == null ? "" : Safe(tag.Grade);
			if (g.Length == 0)
				return false;

			for (int i = 0; i < gradeFilterArr.Length; i++)
			{
				string f = Safe(gradeFilterArr[i]);
				if (f.Length == 0) continue;
				if (string.Equals(g, f, StringComparison.OrdinalIgnoreCase))
					return true;
				// Allows filtering by grade prefix such as A+, A, B, C, D, F.
				if (g.StartsWith(f + " ", StringComparison.OrdinalIgnoreCase))
					return true;
			}
			return false;
		}

		private bool PassesFilters(SignalRow s)
		{
			if (SideFilter == RsrReviewSideFilter.LongOnly && !string.Equals(s.Side, "LONG", StringComparison.OrdinalIgnoreCase)) return false;
			if (SideFilter == RsrReviewSideFilter.ShortOnly && !string.Equals(s.Side, "SHORT", StringComparison.OrdinalIgnoreCase)) return false;

			if (ModelFilter != RsrReviewSignalModelFilter.All)
			{
				if (ModelFilter == RsrReviewSignalModelFilter.CustomList)
				{
					if (!InCustomModelList(s)) return false;
				}
				else
				{
					if (!string.Equals(s.TypeAbbr, ModelFilter.ToString(), StringComparison.OrdinalIgnoreCase)) return false;
				}
			}

			switch (OutcomeFilter)
			{
				case RsrReviewOutcomeFilter.CleanOnly: if (!s.IsCleanTrade) return false; break;
				case RsrReviewOutcomeFilter.BigMove100Only: if (!s.IsBigMove100) return false; break;
				case RsrReviewOutcomeFilter.CleanOrBigMove: if (!(s.IsCleanTrade || s.IsBigMove100)) return false; break;
				case RsrReviewOutcomeFilter.TinyNoiseOnly: if (!s.IsTinyNoise) return false; break;
				case RsrReviewOutcomeFilter.HighMaeOnly: if (!s.IsHighMae) return false; break;
				case RsrReviewOutcomeFilter.ProblemOnly: if (!(s.IsTinyNoise || s.IsHighMae)) return false; break;
				case RsrReviewOutcomeFilter.NonCleanOnly: if (s.IsCleanTrade) return false; break;
				case RsrReviewOutcomeFilter.SwingLegOnly: if (!s.AtSwingLeg) return false; break;
				case RsrReviewOutcomeFilter.FreshExtremeOnly: if (!s.Fresh20Extreme) return false; break;
				case RsrReviewOutcomeFilter.FractalPivotOnly: if (!s.AtFractalPivot) return false; break;
			}

			if (UseMinAbsorptionZ && (!Valid(s.AbsorptionZ) || s.AbsorptionZ < MinAbsorptionZ)) return false;
			if (UseMinMfe60 && (!Valid(s.Mfe60) || s.Mfe60 < MinMfe60)) return false;
			if (UseMaxMae60 && Valid(s.Mae60) && s.Mae60 > MaxMae60) return false;

			return true;
		}

		private bool InCustomModelList(SignalRow s)
		{
			string[] parts = (CustomModelList ?? "").Split(',');
			for (int i = 0; i < parts.Length; i++)
			{
				string f = (parts[i] ?? "").Trim();
				if (f.Length == 0) continue;
				if (string.Equals(f, s.TypeAbbr, StringComparison.OrdinalIgnoreCase)) return true;
				if (string.Equals(f, s.ModelAlias, StringComparison.OrdinalIgnoreCase)) return true;
				if (string.Equals(f, s.InternalModelId, StringComparison.OrdinalIgnoreCase)) return true;
				if (string.Equals(f, s.ModelName, StringComparison.OrdinalIgnoreCase)) return true;
				if (string.Equals(f, s.Type, StringComparison.OrdinalIgnoreCase)) return true;
			}
			return false;
		}

		private bool IsLong(SignalRow s)
		{
			return s != null && string.Equals(s.Side, "LONG", StringComparison.OrdinalIgnoreCase);
		}

		private double GetAnchorPrice(SignalRow s)
		{
			bool isLong = IsLong(s);

			if (AnchorMode == RsrReviewAnchorMode.CsvEntryPrice && Valid(s.EntryPrice))
				return s.EntryPrice + (isLong ? -SignalOffsetTicks * TickSize : SignalOffsetTicks * TickSize);

			if (AnchorMode == RsrReviewAnchorMode.ChartBarHighLow && Bars != null)
			{
				try
				{
					int bi = Bars.GetBar(s.TsChart);
					if (bi >= 0 && bi < Bars.Count)
					{
						double p = isLong ? Bars.GetLow(bi) : Bars.GetHigh(bi);
						return p + (isLong ? -SignalOffsetTicks * TickSize : SignalOffsetTicks * TickSize);
					}
				}
				catch { }
			}

			double anchor = isLong ? s.SigLow : s.SigHigh;
			if (!Valid(anchor)) anchor = s.EntryPrice;
			if (!Valid(anchor)) anchor = isLong ? s.AbsorpLow : s.AbsorpHigh;
			if (!Valid(anchor)) anchor = s.SigClose;
			if (Valid(anchor))
				return anchor + (isLong ? -SignalOffsetTicks * TickSize : SignalOffsetTicks * TickSize);

			return double.NaN;
		}
		#endregion

		#region CSV/time helpers
		private static Dictionary<string, int> HeaderMap(List<string> hdr)
		{
			Dictionary<string, int> d = new Dictionary<string, int>();
			for (int i = 0; i < hdr.Count; i++)
			{
				string h = NormalizeHeader(hdr[i]);
				if (!d.ContainsKey(h)) d[h] = i;
			}
			return d;
		}

		private static string NormalizeHeader(string s)
		{
			return (s ?? "").Trim().ToLowerInvariant().Replace(" ", "_");
		}

		private static int HeaderIdx(Dictionary<string, int> ix, params string[] names)
		{
			for (int i = 0; i < names.Length; i++)
			{
				string n = NormalizeHeader(names[i]);
				if (ix.ContainsKey(n)) return ix[n];
			}
			return -1;
		}

		private static string Get(List<string> f, int idx)
		{
			if (idx < 0 || idx >= f.Count) return "";
			return (f[idx] ?? "").Trim();
		}

		private static double GetD(List<string> f, Dictionary<string, int> ix, params string[] names)
		{
			int idx = HeaderIdx(ix, names);
			if (idx < 0 || idx >= f.Count) return double.NaN;
			double v;
			string s = (f[idx] ?? "").Trim();
			if (s.Length == 0 || string.Equals(s, "nan", StringComparison.OrdinalIgnoreCase) || string.Equals(s, "na", StringComparison.OrdinalIgnoreCase)) return double.NaN;
			if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v)) return v;
			return double.NaN;
		}

		private static bool GetB(List<string> f, Dictionary<string, int> ix, string name)
		{
			int idx = HeaderIdx(ix, name);
			if (idx < 0 || idx >= f.Count) return false;
			string s = (f[idx] ?? "").Trim().ToLowerInvariant();
			return s == "1" || s == "true" || s == "t" || s == "yes" || s == "y";
		}

		private static int ParseInt(string s)
		{
			int v;
			if (int.TryParse((s ?? "").Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out v)) return v;
			return 0;
		}

		private static List<string> SplitCsv(string line) { return SplitCsv(line, ','); }
		private static List<string> SplitCsv(string line, char delim)
		{
			List<string> res = new List<string>();
			StringBuilder sb = new StringBuilder();
			bool q = false;
			for (int i = 0; i < line.Length; i++)
			{
				char c = line[i];
				if (q)
				{
					if (c == '"')
					{
						if (i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; }
						else q = false;
					}
					else sb.Append(c);
				}
				else
				{
					if (c == '"') q = true;
					else if (c == delim) { res.Add(sb.ToString()); sb.Length = 0; }
					else sb.Append(c);
				}
			}
			res.Add(sb.ToString());
			return res;
		}

		private static readonly string[] TsFormats = {
			"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd H:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd H:mm",
			"yyyy/MM/dd HH:mm:ss", "M/d/yyyy H:mm:ss", "M/d/yyyy h:mm:ss tt", "M/d/yyyy H:mm", "M/d/yyyy h:mm tt" };

		private static bool TryParseTs(string s, out DateTime dt)
		{
			s = (s ?? "").Trim();
			if (s.Length == 0) { dt = DateTime.MinValue; return false; }
			if (DateTime.TryParseExact(s, TsFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)) return true;
			if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)) return true;
			return false;
		}

		private static string TsKey(DateTime dt)
		{
			return dt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
		}

		private static string Esc(string f)
		{
			if (f == null) f = "";
			if (f.IndexOf(',') >= 0 || f.IndexOf('"') >= 0 || f.IndexOf('\n') >= 0 || f.IndexOf('\r') >= 0)
				return "\"" + f.Replace("\"", "\"\"") + "\"";
			return f;
		}

		private static bool Valid(double v)
		{
			return !(double.IsNaN(v) || double.IsInfinity(v));
		}

		private static string F(double v)
		{
			if (!Valid(v)) return "na";
			return v.ToString("0.##", CultureInfo.InvariantCulture);
		}

		private static string Signed(double v)
		{
			if (!Valid(v)) return "na";
			return (v >= 0 ? "+" : "") + v.ToString("0.##", CultureInfo.InvariantCulture);
		}

		private static string B(bool b)
		{
			return b ? "TRUE" : "FALSE";
		}

		private static string Safe(string s)
		{
			return string.IsNullOrWhiteSpace(s) ? "" : s.Trim();
		}

		private static string TitleCase(string s)
		{
			s = Safe(s).ToLowerInvariant();
			if (s.Length == 0) return "";
			return s.Substring(0, 1).ToUpperInvariant() + (s.Length > 1 ? s.Substring(1) : "");
		}

		private static string TrimEndLines(string s)
		{
			if (s == null) return "";
			return s.TrimEnd('\r', '\n', ' ', '\t');
		}
		#endregion
	}

	// =============================== Label popup ===============================
	public class ReversalSignalReviewWindow : Window
	{
		private ComboBox gradeBox;
		private ComboBox reasonBox;
		private TextBox noteBox;
		private readonly Action<string, string, string, bool> onSave;

		public ReversalSignalReviewWindow(string signalId, string details, string curGrade, string curReason, string curNote,
			string[] grades, string[] reasons, Action<string, string, string, bool> save)
		{
			onSave = save;
			Title = "Review signal " + signalId;
			SizeToContent = SizeToContent.WidthAndHeight;
			ResizeMode = ResizeMode.NoResize;
			WindowStartupLocation = WindowStartupLocation.CenterScreen;
			Topmost = true;
			Background = new SolidColorBrush(Color.FromRgb(0x0B, 0x20, 0x2F));

			StackPanel root = new StackPanel { Margin = new Thickness(16), MinWidth = 510 };

			TextBlock title = new TextBlock
			{
				Text = "Signal Review",
				Foreground = new SolidColorBrush(Color.FromRgb(0xF7, 0xD4, 0x75)),
				FontSize = 16,
				FontWeight = FontWeights.SemiBold,
				Margin = new Thickness(0, 0, 0, 3)
			};
			root.Children.Add(title);

			TextBlock subtitle = new TextBlock
			{
				Text = signalId,
				Foreground = new SolidColorBrush(Color.FromRgb(0x79, 0xFF, 0xCD)),
				FontSize = 11,
				Margin = new Thickness(0, 0, 0, 10)
			};
			root.Children.Add(subtitle);

			TextBox detailBox = new TextBox
			{
				Text = details ?? "",
				IsReadOnly = true,
				TextWrapping = TextWrapping.Wrap,
				AcceptsReturn = true,
				MinHeight = 170,
				MaxHeight = 230,
				MinWidth = 510,
				Foreground = new SolidColorBrush(Color.FromRgb(0xF4, 0xFA, 0xFF)),
				Background = new SolidColorBrush(Color.FromRgb(0x08, 0x18, 0x25)),
				BorderBrush = new SolidColorBrush(Color.FromRgb(0x2E, 0x70, 0x78)),
				Margin = new Thickness(0, 0, 0, 12)
			};
			root.Children.Add(detailBox);

			root.Children.Add(Lbl("Fast grade", true));
			StackPanel quick = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 8) };
			AddQuickGrade(quick, "A+ Amazing");
			AddQuickGrade(quick, "A Great");
			AddQuickGrade(quick, "B Good / Usable");
			AddQuickGrade(quick, "B- Small but Manageable");
			AddQuickGrade(quick, "C Questionable");
			AddQuickGrade(quick, "D Unacceptable");
			AddQuickGrade(quick, "F Horrid");
			root.Children.Add(quick);

			gradeBox = new ComboBox { MinWidth = 240, Margin = new Thickness(0, 2, 0, 10), IsEditable = true };
			gradeBox.Items.Add("");
			if (grades != null)
			{
				for (int i = 0; i < grades.Length; i++)
					if (!string.IsNullOrWhiteSpace(grades[i])) gradeBox.Items.Add(grades[i]);
			}
			gradeBox.Text = curGrade ?? "";
			root.Children.Add(gradeBox);

			root.Children.Add(Lbl("Reason / Caution", true));
			reasonBox = new ComboBox { MinWidth = 500, Margin = new Thickness(0, 2, 0, 10), IsEditable = true };
			reasonBox.Items.Add("");
			if (reasons != null)
			{
				for (int i = 0; i < reasons.Length; i++)
					if (!string.IsNullOrWhiteSpace(reasons[i])) reasonBox.Items.Add(reasons[i]);
			}
			reasonBox.Text = curReason ?? "";
			root.Children.Add(reasonBox);

			root.Children.Add(Lbl("Review Notes", true));
			noteBox = new TextBox
			{
				Text = curNote ?? "",
				TextWrapping = TextWrapping.Wrap,
				AcceptsReturn = true,
				MinHeight = 70,
				MinWidth = 510,
				Foreground = new SolidColorBrush(Color.FromRgb(0xF4, 0xFA, 0xFF)),
				Background = new SolidColorBrush(Color.FromRgb(0x08, 0x18, 0x25)),
				BorderBrush = new SolidColorBrush(Color.FromRgb(0x2E, 0x70, 0x78)),
				Margin = new Thickness(0, 2, 0, 12)
			};
			root.Children.Add(noteBox);

			root.Children.Add(Buttons());
			Content = root;
		}

		private void AddQuickGrade(StackPanel panel, string grade)
		{
			string display = grade;
			int sp = grade.IndexOf(' ');
			if (sp > 0) display = grade.Substring(0, sp);
			Button b = Btn(display, Color.FromRgb(0x12, 0x39, 0x4A));
			b.ToolTip = grade;
			b.Padding = new Thickness(8, 4, 8, 4);
			b.Margin = new Thickness(0, 0, 6, 0);
			b.Click += delegate { gradeBox.Text = grade; };
			panel.Children.Add(b);
		}

		private UIElement Buttons()
		{
			StackPanel sp = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
			Button delete = Btn("Delete label", Color.FromRgb(0x78, 0x36, 0x45));
			Button cancel = Btn("Cancel", Color.FromRgb(0x28, 0x42, 0x55));
			Button save = Btn("Save Label", Color.FromRgb(0x17, 0x8D, 0x76));

			delete.Click += delegate
			{
				if (onSave != null) onSave("", "", "", true);
				Close();
			};
			cancel.Click += delegate { Close(); };
			save.Click += delegate
			{
				string grade = gradeBox.Text ?? "";
				string reason = reasonBox.Text ?? "";
				string note = noteBox.Text ?? "";
				if (onSave != null) onSave(grade.Trim(), reason.Trim(), note.Trim(), false);
				Close();
			};

			sp.Children.Add(delete);
			sp.Children.Add(cancel);
			sp.Children.Add(save);
			return sp;
		}

		private TextBlock Lbl(string t, bool bold)
		{
			return new TextBlock
			{
				Text = t,
				FontSize = 11,
				Foreground = new SolidColorBrush(Color.FromRgb(0xF7, 0xD4, 0x75)),
				FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal,
				Margin = new Thickness(0, 6, 0, 2)
			};
		}

		private Button Btn(string t, Color bg)
		{
			return new Button
			{
				Content = t,
				Margin = new Thickness(8, 4, 0, 0),
				Padding = new Thickness(14, 6, 14, 6),
				Foreground = new SolidColorBrush(Color.FromRgb(0xF4, 0xFA, 0xFF)),
				Background = new SolidColorBrush(bg),
				BorderBrush = new SolidColorBrush(Color.FromRgb(0x79, 0xFF, 0xCD)),
				BorderThickness = new Thickness(1)
			};
		}
	}
}
